import React from 'react'
import "../JJT/JjtElements.css"
import awan3 from "../../images/awan5.png"

function jjt() {
  return (
    <div className="Bg4" id='jelajahteknik'> 
       <div className='max-width'>
            <div className='kotak'>
            <div className='Awan3'>
              <img src={awan3} />
            </div>
                <div className='kotak2'></div>
                <div className='kotak3'>
                <div className='kotak1'></div>
                <div className='jjt1'> Jalan-Jalan Teknik </div>
                </div>
                </div>
            </div>
</div>
    
    
    
    
  )
}

export default jjt