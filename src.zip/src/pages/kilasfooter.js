import React from 'react'
import Kilas from '../Components/Kilasbalik'
import Footer from '../Components/Footer';
import "../pages/kilasfooter.css"

function KilasFooter() {
  return (
    <>
    <div className="Bg10"> 
        <Kilas />
        <Footer />
    </div>
    </>
  )
}

export default KilasFooter